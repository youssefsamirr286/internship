package jtag.internship_project.entities;

public enum TransactionTypeEnum {
	INCOME, EXPENSE
}
